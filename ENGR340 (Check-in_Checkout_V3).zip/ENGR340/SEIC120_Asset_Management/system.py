# file: checkin.py
# Run with: python checkin.py
#
# Data files (auto-created in the same folder):
#   - checked_in.json   (set of 9-digit IDs currently inside)
#   - approved_ids.json (set of approved 9-digit IDs)
#   - admin.json        (salted hash of admin password)
#   - items.json        (dict: 4-digit code -> {"name": str, "holder": "9digits" or None})

import json
from pathlib import Path
import hashlib
import os

DB_CHECKED_IN = Path("checked_in.json")
DB_APPROVED   = Path("approved_ids.json")
DB_ADMIN      = Path("admin.json")
DB_ITEMS      = Path("items.json")

# ---------- tiny persistence ----------
def _load_set(path: Path) -> set:
    if path.exists():
        try:
            data = json.loads(path.read_text())
            if isinstance(data, dict):
                values = data.get("values") or data.get("checked_in") or data.get("approved")
            else:
                values = data
            return set(values or [])
        except Exception:
            return set()
    return set()

def _save_set(path: Path, items: set, key: str = "values"):
    path.write_text(json.dumps({key: sorted(items)}))

def _load_items() -> dict:
    if DB_ITEMS.exists():
        try:
            data = json.loads(DB_ITEMS.read_text())
            return data.get("items", {})
        except Exception:
            return {}
    return {}

def _save_items(items: dict):
    DB_ITEMS.write_text(json.dumps({"items": items}, indent=2))

def load_checked_in() -> set: return _load_set(DB_CHECKED_IN)
def save_checked_in(s: set):  _save_set(DB_CHECKED_IN, s, key="checked_in")

def load_approved() -> set:   return _load_set(DB_APPROVED)
def save_approved(s: set):    _save_set(DB_APPROVED, s, key="approved")

# ---------- admin auth (visible input by request) ----------
def _sha256_hex(s: str) -> str: return hashlib.sha256(s.encode("utf-8")).hexdigest()
def _salted_hash(pw: str, salt: str) -> str: return _sha256_hex(salt + pw)

def _load_admin_rec():
    if DB_ADMIN.exists():
        try: return json.loads(DB_ADMIN.read_text())
        except Exception: pass
    return None

def _save_admin_rec(rec: dict): DB_ADMIN.write_text(json.dumps(rec))

def ensure_admin_setup():
    """On first run, create admin password (typed visibly)."""
    rec = _load_admin_rec()
    if rec and "salt" in rec and "hash" in rec:
        return
    print("=== Initial admin setup (password will be visible as you type) ===")
    while True:
        pw1 = input("Create admin password: ")
        pw2 = input("Confirm admin password: ")
        if not pw1:
            print("Password cannot be empty.")
            continue
        if pw1 != pw2:
            print("Passwords do not match, try again.")
            continue
        break
    salt = os.urandom(16).hex()
    _save_admin_rec({"salt": salt, "hash": _salted_hash(pw1, salt)})
    print("Admin password set.\n")

def admin_login() -> bool:
    rec = _load_admin_rec()
    if not rec:
        print("Admin is not configured. Run the program again.")
        return False
    attempt = input("Admin password (visible): ")
    ok = _salted_hash(attempt, rec["salt"]) == rec["hash"]
    if not ok:
        print("❌ Invalid admin password.")
    return ok

def admin_change_password():
    if not admin_login():
        return
    salt = os.urandom(16).hex()
    while True:
        pw1 = input("New admin password (visible): ")
        pw2 = input("Confirm new password (visible): ")
        if not pw1:
            print("Password cannot be empty.")
            continue
        if pw1 != pw2:
            print("Passwords do not match, try again.")
            continue
        break
    _save_admin_rec({"salt": salt, "hash": _salted_hash(pw1, salt)})
    print("✅ Admin password updated.")

# ---------- validation ----------
def is_valid_nine_digit(s: str) -> bool: return s.isdigit() and len(s) == 9
def is_valid_code4(s: str) -> bool: return s.isdigit() and len(s) == 4

# ---------- menus & help ----------
HELP = """
How it works:
  • Only APPROVED 9-digit IDs can CHECK IN to the room.
  • While checked IN, a user can CHECK OUT/IN items by 4-digit code.
  • Items are defined by admin as: 4-digit CODE + NAME (e.g., 0007 Projector).
  • An item shows who holds it (the 9-digit ID) until returned.
"""

def show_main_menu():
    print("""
================= CHECK-IN / CHECK-OUT =================
Type one of the letters/numbers below and press Enter:

  1  → Check IN to the room (approved IDs only)
  2  → Check OUT of the room
  I  → Items menu (for checked-in users)
  L  → List all IDs currently checked IN
  C  → Show count of people inside
  A  → Admin menu (manage approvals, items, password, reset)
  H  → Help (re-show the info below)
  Q  → Quit

========================================================
""".rstrip())
    print(HELP.strip(), end="\n\n")

def show_admin_menu():
    print("""
---------------------- ADMIN ---------------------------
Type one of the letters/numbers below and press Enter:

  1  → Add APPROVED 9-digit ID
  2  → Remove APPROVED 9-digit ID
  3  → List APPROVED IDs
  P  → Change admin password
  ----- Items -----
  4  → Add ITEM (format: 4-digit code + name)
  5  → Remove ITEM (by 4-digit code)
  6  → List ITEMS and status
  R  → Reset EVERYTHING (admin + approvals + check-ins + items)
  B  → Back to main menu
--------------------------------------------------------
""".rstrip())

def show_items_menu(current_user):
    print(f"""
----------------------- ITEMS --------------------------
Current user: {current_user or '— (no active user; please check IN)'}
Type one of the letters/numbers below and press Enter:

  1  → Check OUT an item (enter 4-digit code)
  2  → Check IN  an item (enter 4-digit code)
  3  → List ITEMS and who holds them
  B  → Back to main menu
--------------------------------------------------------
""".rstrip())

# ---------- printers ----------
def print_items(items: dict):
    if items:
        print("Items (status):")
        for code in sorted(items):
            name = items[code]["name"]
            holder = items[code]["holder"]
            status = f"checked out by {holder}" if holder else "available"
            print(f"  {code}  {name}  —  {status}")
    else:
        print("No items yet.")

# ---------- prompts ----------
def prompt_id(prompt: str) -> str:
    while True:
        sid = input(prompt).strip()
        if is_valid_nine_digit(sid):
            return sid
        print("❌ Invalid ID. Please enter exactly nine digits (e.g., 123456789).")

def prompt_code4(prompt: str) -> str:
    while True:
        code = input(prompt).strip()
        if is_valid_code4(code):
            return code
        print("❌ Invalid code. Enter exactly four digits (e.g., 0007).")

# ---------- destructive reset ----------
def reset_everything():
    if not admin_login():
        return
    print("⚠️  This will ERASE admin password, approvals, check-ins, and items.")
    if input("Type RESET to confirm: ").strip() != "RESET":
        print("Canceled.")
        return
    for p in [DB_ADMIN, DB_APPROVED, DB_CHECKED_IN, DB_ITEMS]:
        try:
            if p.exists():
                p.unlink()
        except Exception as e:
            print(f"Could not remove {p.name}: {e}")
    print("✅ All data cleared. Please restart to reconfigure admin.")

# ---------- admin actions ----------
def admin_menu(approved: set, items: dict):
    if not admin_login():
        return
    while True:
        show_admin_menu()
        choice = input("Admin selection: ").strip().lower()
        if choice == "b":
            return
        elif choice == "1":
            sid = prompt_id("Enter 9-digit ID to APPROVE: ")
            if sid in approved:
                print(f"ℹ️  {sid} already approved.")
            else:
                approved.add(sid); save_approved(approved); print(f"✅ Approved: {sid}")
        elif choice == "2":
            sid = prompt_id("Enter 9-digit ID to REMOVE from approvals: ")
            if sid in approved:
                approved.remove(sid); save_approved(approved); print(f"✅ Removed: {sid}")
            else:
                print(f"ℹ️  {sid} not in approvals.")
        elif choice == "3":
            if approved:
                print("Approved IDs:")
                for i, sid in enumerate(sorted(approved), 1):
                    print(f"  {i}. {sid}")
            else:
                print("No approved IDs yet.")
        elif choice == "p":
            admin_change_password()
        elif choice == "4":
            line = input("Enter item as 'CODE NAME' (e.g., 0007 Projector): ").strip()
            if not line:
                print("Nothing entered."); continue
            parts = line.split(maxsplit=1)
            if len(parts) < 2 or not is_valid_code4(parts[0]):
                print("❌ Format must be: 4-digit CODE + NAME"); continue
            code, name = parts[0], parts[1].strip()
            if code in items:
                print(f"ℹ️  Item {code} already exists: {items[code]['name']}")
            else:
                items[code] = {"name": name, "holder": None}; _save_items(items); print(f"✅ Added item {code}: {name}")
        elif choice == "5":
            code = prompt_code4("Enter 4-digit code to REMOVE: ")
            if code in items:
                if items[code]["holder"]:
                    print("⚠️ Removing an item that is currently checked out.")
                del items[code]; _save_items(items); print(f"✅ Removed item {code}.")
            else:
                print("Not found.")
        elif choice == "6":
            print_items(items)
        elif choice == "r":
            reset_everything(); return
        else:
            print("Unknown option. Pick 1/2/3/P/4/5/6/R/B.")

# ---------- item actions for users ----------
def items_menu(current_user: str, items: dict, checked_in: set):
    while True:
        show_items_menu(current_user)
        choice = input("Your selection: ").strip().lower()
        if choice == "b":
            return current_user
        elif choice == "3":
            print_items(items)
        elif choice == "1":  # check OUT (show all items first)
            if not current_user or current_user not in checked_in:
                print("🚫 You must be checked IN to check out items."); continue
            print_items(items)  # <— show items and status before selecting
            code = prompt_code4("Enter 4-digit item code to CHECK OUT: ")
            if code not in items:
                print("Not found."); continue
            if items[code]["holder"]:
                print(f"🚫 Already checked out by {items[code]['holder']}."); continue
            items[code]["holder"] = current_user
            _save_items(items)
            print(f"✅ Checked OUT: {code} {items[code]['name']} → {current_user}")
        elif choice == "2":  # check IN (return)
            if not current_user or current_user not in checked_in:
                print("🚫 You must be checked IN to return items."); continue
            code = prompt_code4("Enter 4-digit item code to CHECK IN (return): ")
            if code not in items:
                print("Not found."); continue
            if items[code]["holder"] != current_user:
                who = items[code]["holder"] or "no one"
                print(f"🚫 You cannot return this item (holder: {who})."); continue
            items[code]["holder"] = None
            _save_items(items)
            print(f"✅ Returned: {code} {items[code]['name']}")
        else:
            print("Unknown option. Pick 1/2/3/B.")

# ---------- main loop ----------
def main():
    ensure_admin_setup()
    checked_in = load_checked_in()
    approved   = load_approved()
    items      = _load_items()

    current_user = None  # last user who checked IN during this session

    while True:
        show_main_menu()
        choice = input("Your selection: ").strip().lower()

        if choice == "q":
            print("Goodbye!"); break
        elif choice == "h":
            print(HELP.strip())
        elif choice == "l":
            if checked_in:
                print("Currently checked IN:")
                for i, sid in enumerate(sorted(checked_in), 1):
                    print(f"  {i}. {sid}")
            else:
                print("No one is currently checked IN.")
        elif choice == "c":
            print(f"Count inside: {len(checked_in)}")
        elif choice == "a":
            admin_menu(approved, items)
        elif choice == "i":
            current_user = items_menu(current_user, items, checked_in)
        elif choice == "1":  # Check IN (must be approved)
            sid = prompt_id("Enter 9-digit Student ID to CHECK IN: ")
            if sid not in approved:
                print(f"🚫 ACCESS DENIED: {sid} is not approved.")
            elif sid in checked_in:
                print(f"ℹ️  {sid} is already checked IN.")
                current_user = sid  # set active user anyway
            else:
                checked_in.add(sid); save_checked_in(checked_in)
                current_user = sid
                print(f"✅ Checked IN:  {sid}")
                # Optionally jump to items menu
                go = input("Open Items menu now? (y/N): ").strip().lower()
                if go == "y":
                    current_user = items_menu(current_user, items, checked_in)
        elif choice == "2":  # Check OUT of room
            sid = prompt_id("Enter 9-digit Student ID to CHECK OUT of room: ")
            if sid in checked_in:
                checked_in.remove(sid); save_checked_in(checked_in)
                print(f"✅ Checked OUT of room: {sid}")
                if current_user == sid:
                    current_user = None
            else:
                print(f"ℹ️  {sid} is not currently checked IN.")
        else:
            print("Unknown option. Please choose one shown in the menu.")

if __name__ == "__main__":
    main()